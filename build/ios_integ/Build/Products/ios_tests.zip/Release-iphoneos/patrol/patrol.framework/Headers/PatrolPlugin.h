#import <Flutter/Flutter.h>

@interface PatrolPlugin : NSObject <FlutterPlugin>
@end
