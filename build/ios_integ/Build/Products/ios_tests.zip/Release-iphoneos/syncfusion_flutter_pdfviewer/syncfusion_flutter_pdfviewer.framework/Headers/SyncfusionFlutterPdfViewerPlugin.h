#import <Flutter/Flutter.h>

@interface SyncfusionFlutterPdfViewerPlugin : NSObject<FlutterPlugin>
@end
