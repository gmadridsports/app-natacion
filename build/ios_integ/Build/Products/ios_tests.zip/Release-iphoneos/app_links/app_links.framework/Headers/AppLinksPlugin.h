#import <Flutter/Flutter.h>

@interface AppLinksPlugin : NSObject<FlutterPlugin>
@end
